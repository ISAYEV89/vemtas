<figure class="imghvr-stack-up">
  <img src="#" alt="example-image">
  <figcaption>
    <h3 class="ih-fade-down ih-delay-sm ">Oscar Wilde</h3>
    <p class="ih-zoom-in ih-delay-md">
      <i>"I have the simplest tastes, I am always satisfied with the best."</i>
    </p>
    <a class="ih-fade-up ih-delay-lg button" href="#">Read More</a>
  </figcaption>
  <a href="#"></a>
</figure>

https://www.imagehover.io/docs