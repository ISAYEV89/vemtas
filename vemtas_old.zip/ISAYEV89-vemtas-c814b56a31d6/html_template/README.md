# HTML_TEMPLATE
assets/
sass --watch scss:css --style compressed
