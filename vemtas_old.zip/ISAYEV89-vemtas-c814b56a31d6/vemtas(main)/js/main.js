$(document).ready(function () {

/// login

    $('.login-block__input').focusin(function () {
        $('.login-block__info').css("display", "none");
        $(this).children('.login-block__info').css("display", "flex");
    });

    $('.login-block__info').click(function () {
        $('.login-block__info').css("display", "none");
    });

    $('body').click(function () {
        $('.login-block__info').css("display", "none");
    });

    $(".login-block__input > input").click(function (e) {
        e.stopPropagation();
    });

    $('.inst1').click(function () {
        $('.inst-1').css("display", "flex");

    });

    $('.inst2').click(function () {
        $('.inst-2').css("display", "flex");

    });

    $('.login-block__instruction > span').click(function () {

        $(this).parent('.login-block__instruction').fadeOut();

    });


    /// map

    $('.circle-border').click(function () {
        $('.block').addClass('bg-black');
        $('.custom-dialog').css('display', 'block');
    });

    $('.custom-dialog__close').click(function () {
        $('.block').removeClass('bg-black');
        $('.custom-dialog').css('display', 'none');
    })


    ///// choose

    $('.choose-nav__item ').click(function () {
        $('.choose-menu').toggleClass('d-block');
        $('.summary-wrapper').toggleClass('bg-black')
    });

    $('body').click(function () {
        $('.choose-menu').removeClass('d-block');
        $('.summary-wrapper').removeClass('bg-black')
    });

    $(".choose-menu, .choose-nav__item").click(function (e) {
        e.stopPropagation();
    });

});
